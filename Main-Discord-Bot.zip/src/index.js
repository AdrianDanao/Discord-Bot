console.clear();

const Client = require("./Structures/Client.js");

const config = require("./Data/config.json");

const client = new Client();

client.start(config.token);

const express = require("express");

const app = express();

const port = 3000;

app.get("/", (req, res) => res.send("Hello World!"));

app.listen(port, () => console.log("The Webpage Is Now Online!"));