const Event = require("../Structures/Event.js");

module.exports = new Event("ready", (client) => {

  console.log("Bot is Online!")

  const statuses = [
  "Myself Getting Better!",
  "Gussi On Facebook!",
  "Also Cris.p.nyato!"
  ]

  let counter = 0

  const updateStatus = () => {

    client.user.setPresence({
      status: "idle",
      activities: [
        {
          name: statuses[counter],
          type: "WATCHING"
        }
      ]
    })

    if (++counter >= statuses.length) {
      counter = 0
    }

    setTimeout(updateStatus, 1000 * 60 * 5)

  }
  updateStatus();
});