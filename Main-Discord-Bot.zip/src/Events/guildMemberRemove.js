const Event = require("../Structures/Event.js");

const Discord = require("discord.js");

module.exports = new Event("guildMemberRemove", (client, member) => {

    const channel = member.guild.channels.cache.get("847422049786003456");

    if (!channel) return;

    const embed = new Discord.MessageEmbed();

    embed
        .setTitle("Has Left The Salad Land!")
        .setColor("#ff6961")
        .setAuthor(member.user.tag)
        .setThumbnail(member.user.avatarURL({ dynamic: true }))
        .addField("User Joined", member.joinedAt.toUTCString())

    channel.send({ embeds: [embed] });
});