const Event = require("../Structures/Event.js");

const Discord = require("discord.js");

const Canvas = require("canvas");

const { registerFont } = require("canvas");

const applyText = (canvas, text) => {

  const context = canvas.getContext("2d");

  let fontSize = 70;

  do {

    context.font = `${fontSize -= 10}px Cheese Toast`;
  } while (context.measureText(text).width > canvas.width - 300);

  return context.font;
};

module.exports = new Event("guildMemberAdd", async (client, member, message) => {

    const channel = member.guild.channels.cache.get("847422049786003456");

    if (!channel) return console.log("No Channel");

    registerFont("Cheese Toast.ttf", { family: "Cheese Toast" })

    const canvas = Canvas.createCanvas(700, 250);

    const context = canvas.getContext("2d");

    const background = await Canvas.loadImage("https://v12.discordjs.guide/assets/img/canvas-preview.cced9193.png");

    context.drawImage(background, 0, 0, canvas.width, canvas.height);

    context.font = "28px Cheese Toast";

    context.fillStyle = "#FFFFFF";

    context.fillText("Welcome To The Salad Bowl,", canvas.width / 2.5, canvas.height / 3.5);

    context.font = applyText(canvas, `${member.displayName}!`);

    context.fillStyle = "#FFFFFF";

    context.fillText(`${member.displayName}!`, canvas.width / 2.5, canvas.height / 1.8);

    context.beginPath();

    context.arc(125, 125, 100, 0, Math.PI * 2, true);

    context.closePath();

    context.clip();

    const avatar = await Canvas.loadImage(member.user.displayAvatarURL({ format: "jpg" }));

    context.drawImage(avatar, 25, 25, 200, 200);

    const attachment = new Discord.MessageAttachment(canvas.toBuffer(), "welcome-image.png")

    await channel.send({ files: [attachment] });

    const embed = new Discord.MessageEmbed();

    embed
        .setTitle("Has Joined The Salad Land!")
        .setDescription("Please Verify Yourself At #get-verified, And Start Chatting At #gen-chat!")
        .setColor("#ffc1cd")
        .setAuthor(member.user.tag)
        .addFields({
            name: "User Joined",
            value: member.joinedAt.toUTCString(),
            inline: true
        },
        {
            name: "Account Created",
            value: member.user.createdAt.toUTCString(),
            inline: true
        })

    
    channel.send({ embeds: [embed] });
});