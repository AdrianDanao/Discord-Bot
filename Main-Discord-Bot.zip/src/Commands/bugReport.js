const { MessageEmbed } = require('discord.js');
const Command = require('../Structures/Command.js');
const Owner = ('438222179952230402')

module.exports = new Command({
  name: 'bugreport',
  description: 'Reports a bug to the owner',
  permission: "ADMINISTRATOR",
  
  async run(message, args, client) {
      const owner = client.users.cache.get(`${Owner}`);

      const query = args.slice(1).join(" ");
      if(!query) {

      const emBug = new MessageEmbed()
        .setTitle("Details Of The Bug")
        .setDescription("Please Give A Detailed Explanation Of The Bug!")
        .setFooter("Take Note That Abusing This Command Will Lead To Withdrawal Of This Server's Permission To Use It")
        .setColor("#ff6961")
			return message.channel.send({ embeds: [emBug]})
		};

      const reportEmbed = new MessageEmbed()
        .setTitle('A new bug has been found :space_invader: ')
        .setColor("PURPLE")
        .addField('Author:', message.author.toString(), true)
        .addField('Guild:', message.guild.name, true)
        .addField('MemberCount:', message.guild.memberCount.toString(), true)
        .addField('GuildID:', message.guild.id.toString(), true)
        .addField('Report:', query)
        .setThumbnail("https://cdn.discordapp.com/attachments/931647563516485642/934184070966022244/Capture.PNG")
        .setTimestamp();

      client.channels.cache.get("898859582334599188").send({ embeds: [reportEmbed] })
  }
})