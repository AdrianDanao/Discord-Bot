const Command = require("../Structures/Command");

module.exports = new Command({
    name: "clear",
    description: "Clear An Amount Of Messages!",
    permission: "MANAGE_MESSAGES",

    async run(message, args, client) {

        const amount = args[1];

        if (!amount || isNaN(amount)) return message.channel.send(`${amount} Is Not A Valid Number!`);

        const amountParsed = parseInt(amount);

        if (amountParsed > 100) return message.channel.send("You Cannot Clear More Than 100 Messages!");

        message.channel.bulkDelete(amountParsed);

        const msg = await message.channel.send(
            `Cleared ${amountParsed} Messages!`
        );

        setTimeout(() => msg.delete(), 2000);

    }
});