const Command = require("../Structures/Command.js");

const Discord = require("discord.js");

module.exports = new Command({
    name: "ping",
    description: "Shows the ping of the bot!",
    permission: "SEND_MESSAGES",
    async run(message, args, client) {

        const embed = new Discord.MessageEmbed();

        embed
            .setTitle("Your Ping Is:")
            .setDescription(`${client.ws.ping} ms.`)
            .setColor("#ffd1dc");
    
        message.channel.send({ embeds: [embed] });


    }
});