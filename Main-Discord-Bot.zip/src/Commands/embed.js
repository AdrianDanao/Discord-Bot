const Command = require("../Structures/Command.js");

const Discord = require("discord.js");

module.exports = new Command({
    name: "embed",
    description: "shows an embed",
    permission: "SEND_MESSAGES",
    async run (message, args, client) {

        const embed = new Discord.MessageEmbed()
            .setTitle("Fruitsalad!")
            .setURL("https://cdn.discordapp.com/attachments/873407166772551693/875699608565735454/fruit_gang.jpg")
            .setDescription(
                "This Is An Example Of An Embed"
                )
            .setColor("#77DD77");

        message.channel.send({ embeds: [embed] });

    }
});