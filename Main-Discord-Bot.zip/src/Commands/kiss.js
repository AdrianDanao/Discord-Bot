const Discord = require("discord.js");

const Command = require("../Structures/Command.js");

const Event = require("../Structures/Event.js");

const { MessageEmbed, MessageActionRow, MessageButton} = require("discord.js");

const db = require("quick.db");

module.exports = new Command({
  name: "kiss",
  description: "Kisses The Mentioned User",
  permission: "SEND_MESSAGES",
  timeout: 5,
  
  async run(message, args, client) {

    const userToKiss = message.mentions.members.first()

    const emMention = new Discord.MessageEmbed()
      .setTitle("Mention Someone!")
      .setDescription("You Can't Kiss The Air!")
      .setColor("#ff6961")

    const emYou = new Discord.MessageEmbed()
      .setTitle("Self Love!")
      .setDescription(`${userToKiss} Has Kisses Themselves!`)
      .setColor("#eb96eb")

    if (!userToKiss) return message.channel.send({ embeds: [emMention]})

    if (userToKiss == message.member) return message.channel.send({ embeds: [emYou]})

    let Kissed = await db.add(`kiss_${userToKiss.id}`, 1)

    Kissed+1

    const emKiss = new Discord.MessageEmbed()
      .setTitle(message.member.user.tag)
      .setImage("https://64.media.tumblr.com/6a3e50286b6f45fd74c515b66f81e471/tumblr_ni8yoi6qLO1u55xnmo4_500.gif")
      .setDescription(`Has Kissed ${userToKiss} ${Kissed} Times Now! <:eughshy:856158221219790909>`)
      .setColor("#eb96eb")

    message.channel.send({ embeds: [emKiss]});
  }
})