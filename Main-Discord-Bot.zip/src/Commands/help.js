const Command = require("../Structures/Command.js");

const Discord = require("discord.js");

module.exports = new Command({
    name: "help",
    description: "Shows the set of commands",
    permission: "SEND_MESSAGES",
    async run (message, args, client) {

        const emHelp = new Discord.MessageEmbed()
            .setTitle("Fruitsalad!")
            .setURL("https://bit.ly/3k1LJCa")
            .addFields(
                {
                    name: "+clear",
                    value: "Deletes Messages",
                    inline: true

                },
                {
                    name: "+embed",
                    value: "Shows An Example Of An Embed",
                    inline: true

                },
                {
                    name: "+kiss",
                    value: "You Kiss The First User You Mentioned",
                    inline: true
                },
                {
                    name: "+help",
                    value: "Shows You This Message\nUse +help (command) For A Better Explanation Of Each Command",
                    inline: true
                },
                {
                    name: "+ping",
                    value: "Shows Your Ping From The Server"
                },
                {
                    name: "+say",
                    value: "The Bot Repeats What You Say"
                }
                )
            .setColor("#77DD77")
            .setFooter("To Send Bug Reports Of The Bot Use +bugreport <details of bug> To Contact Bot Owner");

        message.member.send({ embeds: [emHelp] });

    }
});